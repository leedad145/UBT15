using System.Data.Common;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// 테스트용 인벤토리 UI 컨트롤러.
/// 프리팹(=GameObject)에 붙이고 RectTransform만 연결하면,
/// 클릭 위치를 그리드 좌표로 변환해서 Domain.Inventory에 아이템을 넣어볼 수 있습니다.
/// </summary>
[DisallowMultipleComponent]
public class InventoryUI : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerDownHandler
{
    [Header("Service SO")]
    [SerializeField] private InventoryServiceLocateSO _inventoryServiceSO;

    [Header("Grid")]
    [SerializeField] private InventoryGrid _inventoryGrid;
    // inventory info 추가
    private InventoryItem? _targetItem = null;
    int originalX;
    int originalY;
    int rotateValue;
    // 재사용 버퍼(할당 방지)

    void Update()
    {
        if(_targetItem == null)
        {
            if (Input.GetMouseButtonDown(0))
            {
                var tile = _inventoryGrid.GetTileGridPosition(Input.mousePosition);
                _inventoryServiceSO.Service.TryPlaceRandomTestItem(tile.x, tile.y);
                GridUpdate();
            }
            else if (Input.GetMouseButtonDown(1))
            {
                var tile = _inventoryGrid.GetTileGridPosition(Input.mousePosition);
                _inventoryServiceSO.Service.PickUpAt(tile.x, tile.y);
                GridUpdate();
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                Rotate(true);
            }
            // T = 반대 방향 회전
            if (Input.GetKeyDown(KeyCode.T))
            {
                Rotate(false);
            }
        }
    }
    #region Input
    public void OnPointerDown(PointerEventData eventData) //클릭
    {
        var tilePos = _inventoryGrid.GetTileGridPosition(eventData.position);
        _targetItem = _inventoryServiceSO.Service.GetItemAt(tilePos.x, tilePos.y);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        var tilePos = _inventoryGrid.GetTileGridPosition(eventData.position);
        _targetItem = _inventoryServiceSO.Service.GetItemAt(tilePos.x, tilePos.y);
        if(_targetItem != null)
        {
            (originalX, originalY) = _inventoryServiceSO.Service.GetItemPos(_targetItem);
            rotateValue = 0;
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (_targetItem == null) return;
        
        var tilePos = _inventoryGrid.GetTileGridPosition(eventData.position);
        
        // 오브젝트가 범위를 벗어나면 이동하지 않음
        if (!_inventoryServiceSO.Service.IsValidPosition(_targetItem, tilePos.x, tilePos.y))
            return;

        Move(tilePos.x, tilePos.y);
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (_targetItem == null) return;

        var tilePos = _inventoryGrid.GetTileGridPosition(eventData.position);

        if(!_inventoryServiceSO.Service.TryMoveItem(_targetItem, tilePos.x, tilePos.y))
        {
            Move(originalX, originalY);
            while(rotateValue != 0)
            {
                if(rotateValue > 0)
                    Rotate(false);
                else
                    Rotate(true);
            }
        }
    }
    #endregion Input
    void Rotate(bool dir)
    {
        _targetItem.Rotate(dir);
        if(dir)
            rotateValue++;
        else
            rotateValue--;

        GridUpdate();
    }
    void Move(int x, int y)
    {
        _inventoryServiceSO.Service.MoveItem(_targetItem, x, y);
        GridUpdate();
    }
    void GridUpdate()
    {
        _inventoryServiceSO.Service.RebuildItemSlot();
        _inventoryGrid.ShowInventoryGrid(_inventoryServiceSO.Service.ItemSlot);
    
    }
}